function App() {
  return (
    <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'flex-start', height: '100vh' }}>
      <h1 style={{ marginTop: '40px' }}>Hello World</h1>
    </div>
  );
}

export default App;
